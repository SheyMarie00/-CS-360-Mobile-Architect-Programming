package com.example.eventplanner;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class appDatabase
{
    public void addUser(String username, String password) {
    }

    public class DBHandler extends SQLiteOpenHelper
    {
        private static final String DB_NAME = "Eventdb";
        private static final int DB_VERSION = 1;
        private static final String TABLE_NAME = "myEvents";
        private static final String TABLE_USER = "Users";
        private static final String ID_COL = "id";
        private static final String NAME_COL = "name";
        private static final String DATE_COL = "date";
        private static final String DESCRIPTION_COL = "description";

        private static final String USER_NAME = "username";
        private static final String PASSWORD = "password";

        public DBHandler(Context context)
        {
            super(context, DB_NAME, null, DB_VERSION);
        }
        @Override
        public void onCreate(SQLiteDatabase db)
        {
            String event = "CREATE TABLE " + TABLE_NAME + " ("
                    + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + NAME_COL + " TEXT,"
                    + DATE_COL + " TEXT,"
                    + DESCRIPTION_COL + " TEXT)";

            // at last we are calling a exec sql
            // method to execute above sql query
            db.execSQL(event);
            String user = "CREATE TABLE " + TABLE_USER + " ("
                    + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + USER_NAME + " TEXT,"
                    + PASSWORD + " TEXT)";
            db.execSQL(user);
        }
        //creates user
        public void addUser(String userName, String password)
        {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put(USER_NAME, userName);
            values.put(PASSWORD, password);
            db.insert(TABLE_USER, null, values);
            db.close();
        }

        //creating a method for new events
        public void addNewEvent(String eventName, String eventDate, String eventDescription)
        {
            SQLiteDatabase db = this.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(NAME_COL, eventName);
            values.put(DATE_COL, eventDate);
            values.put(DESCRIPTION_COL, eventDescription);

            db.insert(TABLE_NAME, null, values);
            db.close();
        }
        // we have created a new method for reading all the courses.
        public ArrayList<EventModal> readEvents() {
            // on below line we are creating a
            // database for reading our database.
            SQLiteDatabase db = this.getReadableDatabase();

            // on below line we are creating a cursor with query to read data from database.
            Cursor cursorEvents = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

            // on below line we are creating a new array list.
            ArrayList<EventModal> eventModalArrayList = new ArrayList<>();

            // moving our cursor to first position.
            if (cursorEvents.moveToFirst()) {
                do {
                    // on below line we are adding the data from cursor to our array list.
                    eventModalArrayList.add(new EventModal(cursorEvents.getString(1),
                            cursorEvents.getString(3),
                            cursorEvents.getString(2)
                            ));
                } while (cursorEvents.moveToNext());
                // moving our cursor to next.
            }
            // at last closing our cursor
            // and returning our array list.
            cursorEvents.close();
            return eventModalArrayList;
        }
        public void updateEvent(String originalEventName, String eventName, String eventDescription,
                                String eventDate) {

            // calling a method to get writable database.
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            // on below line we are passing all values
            // along with its key and value pair.
            values.put(NAME_COL, eventName);
            values.put(DATE_COL, eventDate);
            values.put(DESCRIPTION_COL, eventDescription);


            // on below line we are calling a update method to update our database and passing our values.
            // and we are comparing it with name of our course which is stored in original name variable.
            db.update(TABLE_NAME, values, "name=?", new String[]{originalEventName});
            db.close();
        }

        // below is the method for deleting our course.
        public void deleteEvent(String eventName) {

            // on below line we are creating
            // a variable to write our database.
            SQLiteDatabase db = this.getWritableDatabase();

            // on below line we are calling a method to delete our
            // course and we are comparing it with our course name.
            db.delete(TABLE_NAME, "name=?", new String[]{eventName});
            db.close();
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
        {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
            onCreate(db);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
            onCreate(db);
        }
    }

}
