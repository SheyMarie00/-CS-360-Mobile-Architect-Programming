package com.example.eventplanner;

@interface ColumnInfo {
    String name();
}
