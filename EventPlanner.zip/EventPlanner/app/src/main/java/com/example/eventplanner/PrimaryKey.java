package com.example.eventplanner;

@interface PrimaryKey {
}
